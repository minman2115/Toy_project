class RetryException(Exception):
    pass
